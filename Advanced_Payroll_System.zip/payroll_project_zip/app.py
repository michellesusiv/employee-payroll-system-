
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import mysql.connector
import hashlib
import secrets
import calendar
from datetime import date, datetime
from decimal import Decimal
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from openpyxl import Workbook

# ---------------- DATABASE CONFIGURATION ----------------

DB_NAME = "advanced_payroll"
MYSQL_HOST = "localhost"
MYSQL_USER = "root"
MYSQL_PASSWORD = "root" # Replace with your MySQL password

GRADE_ALLOWANCE = {"A": 1700, "B": 1500, "C": 1300}


def hash_password(password, salt=None):
    salt = salt or secrets.token_hex(16)
    hashed = hashlib.pbkdf2_hmac(
        "sha256", password.encode(), salt.encode(), 200000
    ).hex()
    return salt, hashed


# ---------------- DATABASE CLASS ----------------

class Database:

    def __init__(self):
        self.conn = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD
        )

        cur = self.conn.cursor()
        cur.execute("CREATE DATABASE IF NOT EXISTS advanced_payroll")
        cur.execute("USE advanced_payroll")

        self.create_tables(cur)
        self.conn.commit()
        cur.close()

        self.add_defaults()

    def create_tables(self, cur):

        cur.execute("""
        CREATE TABLE IF NOT EXISTS users(
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE,
            salt VARCHAR(64),
            password_hash VARCHAR(128)
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS departments(
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(100) UNIQUE
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS grades(
            id INT AUTO_INCREMENT PRIMARY KEY,
            grade_name VARCHAR(10) UNIQUE,
            allowance DECIMAL(10,2)
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS employees(
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_code VARCHAR(30) UNIQUE,
            name VARCHAR(100),
            email VARCHAR(100),
            phone VARCHAR(20),
            department_id INT,
            grade_id INT,
            basic_salary DECIMAL(12,2),
            joining_date DATE,
            active TINYINT DEFAULT 1,
            FOREIGN KEY(department_id) REFERENCES departments(id),
            FOREIGN KEY(grade_id) REFERENCES grades(id)
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS attendance(
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT,
            attendance_date DATE,
            status VARCHAR(20),
            UNIQUE(employee_id, attendance_date),
            FOREIGN KEY(employee_id) REFERENCES employees(id)
            ON DELETE CASCADE
        )
        """)

        cur.execute("""
        CREATE TABLE IF NOT EXISTS payroll(
            id INT AUTO_INCREMENT PRIMARY KEY,
            employee_id INT,
            pay_month INT,
            pay_year INT,
            basic_pay DECIMAL(12,2),
            hra DECIMAL(12,2),
            da DECIMAL(12,2),
            allowance DECIMAL(12,2),
            pf DECIMAL(12,2),
            paid_days INT,
            total_days INT,
            gross_pay DECIMAL(12,2),
            net_pay DECIMAL(12,2),
            UNIQUE(employee_id, pay_month, pay_year),
            FOREIGN KEY(employee_id) REFERENCES employees(id)
            ON DELETE CASCADE
        )
        """)

    def add_defaults(self):

        cur = self.conn.cursor()

        cur.execute("SELECT COUNT(*) FROM users")

        if cur.fetchone()[0] == 0:
            salt, hashed = hash_password("Admin@123")
            cur.execute(
                "INSERT INTO users(username,salt,password_hash) VALUES(%s,%s,%s)",
                ("admin", salt, hashed)
            )

        for department in [
            "Human Resources", "Finance", "Engineering",
            "Operations", "Sales"
        ]:
            cur.execute(
                "INSERT IGNORE INTO departments(name) VALUES(%s)",
                (department,)
            )

        for grade, allowance in GRADE_ALLOWANCE.items():
            cur.execute(
                "INSERT IGNORE INTO grades(grade_name,allowance) VALUES(%s,%s)",
                (grade, allowance)
            )

        self.conn.commit()
        cur.close()

    def execute(self, sql, values=()):
        cur = self.conn.cursor()
        cur.execute(sql, values)
        self.conn.commit()
        cur.close()

    def fetch(self, sql, values=()):
        cur = self.conn.cursor(dictionary=True)
        cur.execute(sql, values)
        result = cur.fetchall()
        cur.close()
        return result


# ---------------- MAIN APPLICATION ----------------

class PayrollApp:

    def __init__(self, root, db):

        self.root = root
        self.db = db

        self.root.title("Advanced Employee Payroll Management System")
        self.root.geometry("1150x700")

        self.style = ttk.Style()
        self.style.theme_use("clam")

        self.login_screen()

    def clear(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    # ---------------- LOGIN ----------------

    def login_screen(self):

        self.clear()

        frame = ttk.Frame(self.root, padding=30)
        frame.place(relx=0.5, rely=0.5, anchor="center")

        ttk.Label(
            frame,
            text="ADVANCED PAYROLL SYSTEM",
            font=("Arial", 20, "bold")
        ).grid(row=0, column=0, columnspan=2, pady=20)

        ttk.Label(frame, text="Username").grid(row=1, column=0, pady=10)

        self.username = ttk.Entry(frame, width=30)
        self.username.grid(row=1, column=1)

        ttk.Label(frame, text="Password").grid(row=2, column=0, pady=10)

        self.password = ttk.Entry(frame, show="*", width=30)
        self.password.grid(row=2, column=1)

        ttk.Button(
            frame,
            text="Login",
            command=self.login
        ).grid(row=3, column=0, columnspan=2, pady=15)

        ttk.Label(
            frame,
            text="Default Login: admin / Admin@123"
        ).grid(row=4, column=0, columnspan=2)

    def login(self):

        username = self.username.get().strip()
        password = self.password.get()

        users = self.db.fetch(
            "SELECT * FROM users WHERE username=%s",
            (username,)
        )

        if not users:
            messagebox.showerror("Error", "Invalid login")
            return

        user = users[0]

        _, hashed = hash_password(password, user["salt"])

        if secrets.compare_digest(hashed, user["password_hash"]):
            self.dashboard()
        else:
            messagebox.showerror("Error", "Invalid password")

    # ---------------- DASHBOARD ----------------

    def dashboard(self):

        self.clear()

        top = ttk.Frame(self.root, padding=15)
        top.pack(fill="x")

        ttk.Label(
            top,
            text="EMPLOYEE PAYROLL DASHBOARD",
            font=("Arial", 18, "bold")
        ).pack(side="left")

        ttk.Button(
            top,
            text="Logout",
            command=self.login_screen
        ).pack(side="right")

        nav = ttk.Frame(self.root, padding=10)
        nav.pack(fill="x")

        buttons = [
            ("Dashboard", self.dashboard),
            ("Employees", self.employee_screen),
            ("Attendance", self.attendance_screen),
            ("Generate Payroll", self.payroll_screen),
            ("Payroll History", self.history_screen),
            ("Analytics", self.analytics_screen),
            ("Change Password", self.change_password)
        ]

        for name, command in buttons:
            ttk.Button(
                nav, text=name, command=command
            ).pack(side="left", padx=4)

        body = ttk.Frame(self.root, padding=25)
        body.pack(fill="both", expand=True)

        employees = self.db.fetch(
            "SELECT COUNT(*) AS n FROM employees WHERE active=1"
        )[0]["n"]

        records = self.db.fetch(
            "SELECT COUNT(*) AS n FROM payroll"
        )[0]["n"]

        total = self.db.fetch(
            "SELECT COALESCE(SUM(net_pay),0) AS n FROM payroll"
        )[0]["n"]

        cards = [
            ("Active Employees", employees),
            ("Payroll Records", records),
            ("Total Net Payroll", f"Rs. {float(total):,.2f}")
        ]

        for i, (title, value) in enumerate(cards):

            card = ttk.LabelFrame(
                body, text=title, padding=25
            )
            card.grid(row=0, column=i, padx=15, sticky="nsew")

            ttk.Label(
                card,
                text=str(value),
                font=("Arial", 19, "bold")
            ).pack()

            body.columnconfigure(i, weight=1)

        ttk.Label(
            body,
            text="Manage employees, attendance, payroll and analytics."
        ).grid(row=1, column=0, columnspan=3, pady=30)

    # ---------------- PAGE HEADER ----------------

    def page_header(self, title):

        bar = ttk.Frame(self.root, padding=12)
        bar.pack(fill="x")

        ttk.Label(
            bar,
            text=title,
            font=("Arial", 18, "bold")
        ).pack(side="left")

        ttk.Button(
            bar,
            text="Home",
            command=self.dashboard
        ).pack(side="right")

    # ---------------- EMPLOYEE MANAGEMENT ----------------

    def employee_screen(self):

        self.clear()
        self.page_header("Employee Management")

        form = ttk.LabelFrame(
            self.root,
            text="Employee Details",
            padding=12
        )
        form.pack(fill="x", padx=15, pady=10)

        fields = [
            ("Employee Code", "code"),
            ("Full Name", "name"),
            ("Email", "email"),
            ("Phone", "phone"),
            ("Basic Salary", "salary"),
            ("Joining Date YYYY-MM-DD", "joining")
        ]

        self.entries = {}

        for i, (label, key) in enumerate(fields):

            row = (i // 3) * 2
            col = i % 3

            ttk.Label(form, text=label).grid(
                row=row, column=col, sticky="w", padx=5
            )

            entry = ttk.Entry(form, width=25)
            entry.grid(row=row+1, column=col, padx=5, pady=5)

            self.entries[key] = entry

        departments = self.db.fetch(
            "SELECT * FROM departments ORDER BY name"
        )

        grades = self.db.fetch(
            "SELECT * FROM grades ORDER BY grade_name"
        )

        self.dep_map = {
            x["name"]: x["id"] for x in departments
        }

        self.grade_map = {
            x["grade_name"]: x["id"] for x in grades
        }

        ttk.Label(form, text="Department").grid(row=4, column=0)

        self.dep = ttk.Combobox(
            form, values=list(self.dep_map),
            state="readonly", width=22
        )
        self.dep.grid(row=5, column=0, padx=5)

        ttk.Label(form, text="Grade").grid(row=4, column=1)

        self.grade = ttk.Combobox(
            form, values=list(self.grade_map),
            state="readonly", width=22
        )
        self.grade.grid(row=5, column=1, padx=5)

        ttk.Button(
            form,
            text="Add Employee",
            command=self.add_employee
        ).grid(row=5, column=2, padx=10)

        cols = (
            "ID", "Code", "Name", "Department",
            "Grade", "Salary", "Status"
        )

        self.emp_tree = ttk.Treeview(
            self.root,
            columns=cols,
            show="headings",
            height=14
        )

        for col in cols:
            self.emp_tree.heading(col, text=col)
            self.emp_tree.column(col, width=140)

        self.emp_tree.pack(
            fill="both", expand=True, padx=15, pady=10
        )

        self.load_employees()

        buttons = ttk.Frame(self.root)
        buttons.pack(pady=5)

        ttk.Button(
            buttons,
            text="Deactivate Selected",
            command=self.deactivate_employee
        ).pack(side="left", padx=5)

        ttk.Button(
            buttons,
            text="Delete Selected",
            command=self.delete_employee
        ).pack(side="left", padx=5)

    def add_employee(self):

        try:
            v = {
                k: e.get().strip()
                for k, e in self.entries.items()
            }

            if not v["code"] or not v["name"] or not v["salary"]:
                raise ValueError("Code, name and salary are required.")

            salary = float(v["salary"])

            if salary <= 0:
                raise ValueError("Salary must be positive.")

            joining = v["joining"] or None

            if joining:
                datetime.strptime(joining, "%Y-%m-%d")

            department = self.dep_map.get(self.dep.get())
            grade = self.grade_map.get(self.grade.get())

            self.db.execute("""
                INSERT INTO employees
                (employee_code,name,email,phone,department_id,
                 grade_id,basic_salary,joining_date)
                VALUES(%s,%s,%s,%s,%s,%s,%s,%s)
            """, (
                v["code"], v["name"], v["email"], v["phone"],
                department, grade, salary, joining
            ))

            messagebox.showinfo("Success", "Employee added.")
            self.employee_screen()

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def load_employees(self):

        for item in self.emp_tree.get_children():
            self.emp_tree.delete(item)

        rows = self.db.fetch("""
            SELECT e.id,e.employee_code,e.name,
            COALESCE(d.name,'-') department,
            COALESCE(g.grade_name,'-') grade,
            e.basic_salary,e.active
            FROM employees e
            LEFT JOIN departments d ON e.department_id=d.id
            LEFT JOIN grades g ON e.grade_id=g.id
            ORDER BY e.id DESC
        """)

        for x in rows:

            self.emp_tree.insert(
                "",
                "end",
                values=(
                    x["id"], x["employee_code"], x["name"],
                    x["department"], x["grade"],
                    f'{float(x["basic_salary"]):.2f}',
                    "Active" if x["active"] else "Inactive"
                )
            )

    def selected_employee(self):

        selected = self.emp_tree.selection()

        if not selected:
            raise ValueError("Select an employee first.")

        return self.emp_tree.item(selected[0])["values"][0]

    def deactivate_employee(self):

        try:
            eid = self.selected_employee()

            self.db.execute(
                "UPDATE employees SET active=0 WHERE id=%s",
                (eid,)
            )

            self.employee_screen()

        except Exception as e:
            messagebox.showerror("Error", str(e))

    def delete_employee(self):

        try:
            eid = self.selected_employee()

            if messagebox.askyesno(
                "Confirm",
                "Permanently delete this employee and their related records?"
            ):
                self.db.execute(
                    "DELETE FROM employees WHERE id=%s",
                    (eid,)
                )
                self.employee_screen()

        except Exception as e:
            messagebox.showerror("Error", str(e))

    # ---------------- ATTENDANCE ----------------

    def attendance_screen(self):

        self.clear()
        self.page_header("Attendance Management")

        employees = self.db.fetch("""
            SELECT id,employee_code,name
            FROM employees WHERE active=1 ORDER BY name
        """)

        self.att_map = {
            f'{x["employee_code"]} - {x["name"]}': x["id"]
            for x in employees
        }

        form = ttk.LabelFrame(
            self.root, text="Mark Daily Attendance", padding=20
        )
        form.pack(padx=20, pady=25)

        ttk.Label(form, text="Employee").grid(row=0, column=0)

        self.att_emp = ttk.Combobox(
            form, values=list(self.att_map),
            state="readonly", width=30
        )
        self.att_emp.grid(row=0, column=1, padx=8)

        ttk.Label(form, text="Date").grid(row=0, column=2)

        self.att_date = ttk.Entry(form, width=15)
        self.att_date.insert(0, date.today().isoformat())
        self.att_date.grid(row=0, column=3, padx=8)

        ttk.Label(form, text="Status").grid(row=1, column=0, pady=15)

        self.att_status = ttk.Combobox(
            form,
            values=["Present", "Absent", "Leave"],
            state="readonly",
            width=15
        )
        self.att_status.set("Present")
        self.att_status.grid(row=1, column=1)

        ttk.Button(
            form,
            text="Save Attendance",
            command=self.save_attendance
        ).grid(row=1, column=2, columnspan=2)

    def save_attendance(self):

        try:
            emp = self.att_map.get(self.att_emp.get())

            if not emp:
                raise ValueError("Select an employee.")

            day = datetime.strptime(
                self.att_date.get(), "%Y-%m-%d"
            ).date()

            status = self.att_status.get()

            self.db.execute("""
                INSERT INTO attendance
                (employee_id,attendance_date,status)
                VALUES(%s,%s,%s)
                ON DUPLICATE KEY UPDATE status=VALUES(status)
            """, (emp, day, status))

            messagebox.showinfo("Saved", "Attendance saved.")

        except Exception as e:
            messagebox.showerror("Error", str(e))

    # ---------------- PAYROLL GENERATION ----------------

    def payroll_screen(self):

        self.clear()
        self.page_header("Generate Monthly Payroll")

        frame = ttk.LabelFrame(
            self.root, text="Select Payroll Period", padding=25
        )
        frame.pack(pady=30)

        ttk.Label(frame, text="Month").grid(row=0, column=0)

        self.pay_month = ttk.Combobox(
            frame, values=list(range(1, 13)),
            state="readonly", width=10
        )
        self.pay_month.set(date.today().month)
        self.pay_month.grid(row=0, column=1, padx=10)

        ttk.Label(frame, text="Year").grid(row=0, column=2)

        self.pay_year = ttk.Entry(frame, width=12)
        self.pay_year.insert(0, str(date.today().year))
        self.pay_year.grid(row=0, column=3, padx=10)

        ttk.Button(
            frame,
            text="Generate Payroll",
            command=self.generate_payroll
        ).grid(row=1, column=0, columnspan=4, pady=20)

        ttk.Label(
            self.root,
            text="HRA = 20% | DA = 50% | PF = 11%\n"
                 "Grade allowance: A = 1700, B = 1500, C = 1300"
        ).pack()

    def generate_payroll(self):

        try:
            month = int(self.pay_month.get())
            year = int(self.pay_year.get())

            total_days = calendar.monthrange(year, month)[1]

            employees = self.db.fetch("""
                SELECT e.id,e.basic_salary,
                COALESCE(g.allowance,0) allowance
                FROM employees e
                LEFT JOIN grades g ON e.grade_id=g.id
                WHERE e.active=1
            """)

            if not employees:
                raise ValueError("No active employees found.")

            for emp in employees:

                attendance = self.db.fetch("""
                    SELECT SUM(status='Present') present_count,
                    COUNT(*) recorded
                    FROM attendance
                    WHERE employee_id=%s
                    AND YEAR(attendance_date)=%s
                    AND MONTH(attendance_date)=%s
                """, (emp["id"], year, month))[0]

                if attendance["recorded"]:
                    paid_days = int(attendance["present_count"] or 0)
                else:
                    paid_days = total_days

                ratio = Decimal(paid_days) / Decimal(total_days)

                basic = Decimal(str(emp["basic_salary"]))
                hra = basic * Decimal("0.20")
                da = basic * Decimal("0.50")
                allowance = Decimal(str(emp["allowance"]))
                pf = basic * Decimal("0.11")

                gross = (basic + hra + da + allowance) * ratio
                net = (basic + hra + da + allowance - pf) * ratio

                self.db.execute("""
                    INSERT INTO payroll
                    (employee_id,pay_month,pay_year,basic_pay,hra,da,
                     allowance,pf,paid_days,total_days,gross_pay,net_pay)
                    VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                    ON DUPLICATE KEY UPDATE
                    basic_pay=VALUES(basic_pay),
                    hra=VALUES(hra),
                    da=VALUES(da),
                    allowance=VALUES(allowance),
                    pf=VALUES(pf),
                    paid_days=VALUES(paid_days),
                    total_days=VALUES(total_days),
                    gross_pay=VALUES(gross_pay),
                    net_pay=VALUES(net_pay)
                """, (
                    emp["id"], month, year, basic, hra, da,
                    allowance, pf, paid_days, total_days, gross, net
                ))

            messagebox.showinfo(
                "Success", "Monthly payroll generated successfully."
            )

        except Exception as e:
            messagebox.showerror("Payroll Error", str(e))

    # ---------------- PAYROLL HISTORY ----------------

    def history_screen(self):

        self.clear()
        self.page_header("Payroll History")

        bar = ttk.Frame(self.root, padding=10)
        bar.pack(fill="x")

        ttk.Button(
            bar, text="Export Excel", command=self.export_excel
        ).pack(side="left", padx=5)

        ttk.Button(
            bar, text="Export Payslip PDF", command=self.export_pdf
        ).pack(side="left", padx=5)

        cols = (
            "ID", "Code", "Name", "Month", "Year",
            "Paid Days", "Gross Pay", "PF", "Net Pay"
        )

        self.hist_tree = ttk.Treeview(
            self.root, columns=cols,
            show="headings", height=18
        )

        for col in cols:
            self.hist_tree.heading(col, text=col)
            self.hist_tree.column(col, width=120)

        self.hist_tree.pack(fill="both", expand=True, padx=15, pady=10)

        self.load_history()

    def history_rows(self):

        return self.db.fetch("""
            SELECT p.*,e.employee_code,e.name,
            e.email,d.name department,g.grade_name
            FROM payroll p
            JOIN employees e ON p.employee_id=e.id
            LEFT JOIN departments d ON e.department_id=d.id
            LEFT JOIN grades g ON e.grade_id=g.id
            ORDER BY p.pay_year DESC,p.pay_month DESC,e.name
        """)

    def load_history(self):

        for item in self.hist_tree.get_children():
            self.hist_tree.delete(item)

        for x in self.history_rows():

            self.hist_tree.insert(
                "", "end",
                values=(
                    x["id"], x["employee_code"], x["name"],
                    x["pay_month"], x["pay_year"],
                    f'{x["paid_days"]}/{x["total_days"]}',
                    f'{float(x["gross_pay"]):.2f}',
                    f'{float(x["pf"]):.2f}',
                    f'{float(x["net_pay"]):.2f}'
                )
            )

    # ---------------- EXCEL EXPORT ----------------

    def export_excel(self):

        try:
            rows = self.history_rows()

            if not rows:
                raise ValueError("No payroll records found.")

            path = filedialog.asksaveasfilename(
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx")]
            )

            if not path:
                return

            wb = Workbook()
            ws = wb.active
            ws.title = "Payroll"

            ws.append([
                "Employee Code", "Name", "Month", "Year",
                "Paid Days", "Basic", "HRA", "DA",
                "Allowance", "PF", "Gross Pay", "Net Pay"
            ])

            for x in rows:
                ws.append([
                    x["employee_code"], x["name"],
                    x["pay_month"], x["pay_year"],
                    f'{x["paid_days"]}/{x["total_days"]}',
                    float(x["basic_pay"]), float(x["hra"]),
                    float(x["da"]), float(x["allowance"]),
                    float(x["pf"]), float(x["gross_pay"]),
                    float(x["net_pay"])
                ])

            wb.save(path)

            messagebox.showinfo("Exported", "Excel report saved successfully.")

        except Exception as e:
            messagebox.showerror("Export Error", str(e))

    # ---------------- PDF PAYSLIP ----------------

    def export_pdf(self):

        try:
            selected = self.hist_tree.selection()

            if not selected:
                raise ValueError("Select a payroll record.")

            payroll_id = self.hist_tree.item(
                selected[0]
            )["values"][0]

            rows = self.db.fetch("""
                SELECT p.*,e.employee_code,e.name,
                d.name department,g.grade_name
                FROM payroll p
                JOIN employees e ON p.employee_id=e.id
                LEFT JOIN departments d ON e.department_id=d.id
                LEFT JOIN grades g ON e.grade_id=g.id
                WHERE p.id=%s
            """, (payroll_id,))

            x = rows[0]

            path = filedialog.asksaveasfilename(
                defaultextension=".pdf",
                filetypes=[("PDF files", "*.pdf")]
            )

            if not path:
                return

            c = canvas.Canvas(path, pagesize=A4)
            width, height = A4

            y = height - 60

            c.setFont("Helvetica-Bold", 18)
            c.drawString(50, y, "EMPLOYEE PAYSLIP")

            c.setFont("Helvetica", 11)
            y -= 45

            lines = [
                f'Employee Name: {x["name"]}',
                f'Employee Code: {x["employee_code"]}',
                f'Department: {x["department"] or "-"}',
                f'Grade: {x["grade_name"] or "-"}',
                f'Pay Period: {x["pay_month"]}/{x["pay_year"]}',
                f'Paid Days: {x["paid_days"]}/{x["total_days"]}',
                "",
                f'Basic Pay: Rs. {float(x["basic_pay"]):,.2f}',
                f'HRA: Rs. {float(x["hra"]):,.2f}',
                f'DA: Rs. {float(x["da"]):,.2f}',
                f'Allowance: Rs. {float(x["allowance"]):,.2f}',
                f'PF Deduction: Rs. {float(x["pf"]):,.2f}',
                f'Gross Pay: Rs. {float(x["gross_pay"]):,.2f}',
                f'NET PAY: Rs. {float(x["net_pay"]):,.2f}'
            ]

            for line in lines:
                c.drawString(60, y, line)
                y -= 25

            c.save()

            messagebox.showinfo("Success", "Payslip PDF created.")

        except Exception as e:
            messagebox.showerror("PDF Error", str(e))

    # ---------------- ANALYTICS ----------------

    def analytics_screen(self):

        self.clear()
        self.page_header("Payroll Analytics")

        fig, axes = plt.subplots(1, 2, figsize=(10, 4))

        departments = self.db.fetch("""
            SELECT COALESCE(d.name,'Unassigned') name,
            SUM(p.net_pay) total
            FROM payroll p
            JOIN employees e ON p.employee_id=e.id
            LEFT JOIN departments d ON e.department_id=d.id
            GROUP BY name
        """)

        if departments:
            axes[0].bar(
                [x["name"] for x in departments],
                [float(x["total"]) for x in departments]
            )
            axes[0].set_title("Department-wise Net Payroll")
            axes[0].tick_params(axis="x", rotation=30)
        else:
            axes[0].text(.5, .5, "No payroll data", ha="center")

        trend = self.db.fetch("""
            SELECT CONCAT(pay_year,'-',LPAD(pay_month,2,'0')) period,
            SUM(net_pay) total
            FROM payroll
            GROUP BY pay_year,pay_month
            ORDER BY pay_year,pay_month
        """)

        if trend:
            axes[1].plot(
                [x["period"] for x in trend],
                [float(x["total"]) for x in trend],
                marker="o"
            )
            axes[1].set_title("Monthly Payroll Trend")
            axes[1].tick_params(axis="x", rotation=30)
        else:
            axes[1].text(.5, .5, "No payroll data", ha="center")

        fig.tight_layout()

        chart = FigureCanvasTkAgg(fig, master=self.root)
        chart.draw()
        chart.get_tk_widget().pack(fill="both", expand=True)

    # ---------------- CHANGE PASSWORD ----------------

    def change_password(self):

        window = tk.Toplevel(self.root)
        window.title("Change Password")
        window.geometry("350x220")

        ttk.Label(window, text="New Password").pack(pady=10)

        p1 = ttk.Entry(window, show="*")
        p1.pack()

        ttk.Label(window, text="Confirm Password").pack(pady=10)

        p2 = ttk.Entry(window, show="*")
        p2.pack()

        def save():

            if len(p1.get()) < 8:
                messagebox.showerror(
                    "Error", "Password must contain at least 8 characters."
                )
                return

            if p1.get() != p2.get():
                messagebox.showerror(
                    "Error", "Passwords do not match."
                )
                return

            salt, hashed = hash_password(p1.get())

            self.db.execute("""
                UPDATE users
                SET salt=%s,password_hash=%s
                WHERE username='admin'
            """, (salt, hashed))

            messagebox.showinfo("Success", "Password changed.")
            window.destroy()

        ttk.Button(
            window, text="Save Password", command=save
        ).pack(pady=15)


# ---------------- RUN APPLICATION ----------------


if __name__ == "__main__":

    if MYSQL_PASSWORD == "YOUR_MYSQL_PASSWORD":
        print("Please enter your MySQL password in app.py.")
    else:
        try:
            database = Database()

            root = tk.Tk()
            application = PayrollApp(root, database)

            def close_app():
                database.conn.close()
                root.destroy()

            root.protocol("WM_DELETE_WINDOW", close_app)
            root.mainloop()

        except Exception as error:
            import traceback
            traceback.print_exc()
            input("Press Enter to close...")
