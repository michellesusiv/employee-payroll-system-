Advanced Employee Payroll Management System

Main file: app.py

Python dependencies:
  pip install -r requirements.txt

Requirements:
- Python 3
- MySQL server running locally
- Update MYSQL_PASSWORD in app.py to match your MySQL root password before running.

Run:
  python app.py

Default application login shown in the source:
  Username: admin
  Password: Admin@123

Change the default application password after the first login.
